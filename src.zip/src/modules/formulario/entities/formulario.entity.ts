export class Formulario {}
